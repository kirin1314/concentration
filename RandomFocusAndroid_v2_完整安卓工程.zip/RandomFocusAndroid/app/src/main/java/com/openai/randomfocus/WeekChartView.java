package com.openai.randomfocus;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.*;

public class WeekChartView extends View {
    private double[] values=new double[7];
    private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG), point=new Paint(Paint.ANTI_ALIAS_FLAG), text=new Paint(Paint.ANTI_ALIAS_FLAG), grid=new Paint(Paint.ANTI_ALIAS_FLAG);
    public WeekChartView(Context c,AttributeSet a){super(c,a);text.setTextAlign(Paint.Align.CENTER);line.setStyle(Paint.Style.STROKE);line.setStrokeWidth(3*c.getResources().getDisplayMetrics().density);point.setStyle(Paint.Style.FILL);grid.setStrokeWidth(1*c.getResources().getDisplayMetrics().density);}
    public void setValues(double[] v){if(v!=null&&v.length==7)values=v.clone();invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float den=getResources().getDisplayMetrics().density,sp=getResources().getDisplayMetrics().scaledDensity,w=getWidth(),h=getHeight(),l=26*den,r=14*den,t=18*den,b=34*sp;float cw=w-l-r,ch=h-t-b;double max=60;for(double x:values)max=Math.max(max,x);max=Math.ceil(max/60.0)*60.0;
        int fg=isNight()?Color.rgb(218,222,232):Color.rgb(68,76,88), muted=isNight()?Color.rgb(148,155,168):Color.rgb(150,156,166);line.setColor(fg);point.setColor(fg);text.setColor(muted);text.setTextSize(11*sp);grid.setColor(isNight()?Color.rgb(50,54,62):Color.rgb(226,229,234));
        for(int k=0;k<=2;k++){float y=t+ch*k/2f;c.drawLine(l,y,l+cw,y,grid);} Path path=new Path(); long today=DataStore.startOfDay(System.currentTimeMillis()); SimpleDateFormat df=new SimpleDateFormat("E",Locale.getDefault());
        for(int i=0;i<7;i++){float x=l+cw*i/6f,y=t+ch-(float)(values[i]/max*ch);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);c.drawCircle(x,y,4*den,point);c.drawText(df.format(new Date(today-(6L-i)*24*60*60*1000)),x,h-8*sp,text);if(values[i]>0)c.drawText(String.format(Locale.getDefault(),"%.1fh",values[i]/60.0),x,Math.max(12*sp,y-8*den),text);}
        c.drawPath(path,line);
    }
    private boolean isNight(){android.util.TypedValue v=new android.util.TypedValue();getContext().getTheme().resolveAttribute(com.openai.randomfocus.R.attr.appBg,v,true);int c=v.data;double lum=(0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))/255.0;return lum<0.5;}
}
