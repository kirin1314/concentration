package com.openai.randomfocus;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.InputStream;

public class UiKit {
    public static final int BLUE = Color.rgb(33, 150, 243);
    public static final int BLUE_DARK = Color.rgb(20, 82, 150);
    public static final int TEXT = Color.rgb(20, 34, 55);
    public static final int MUTED = Color.rgb(108, 126, 153);
    public static final int LINE = Color.rgb(230, 236, 244);

    public static int dp(Context c, int v) { return (int)(v * c.getResources().getDisplayMetrics().density + .5f); }

    public static GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }
    public static GradientDrawable strokeBg(int color, int stroke, int strokeColor, float radius) {
        GradientDrawable g=bg(color,radius); g.setStroke(stroke,strokeColor); return g;
    }
    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t=new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return t;
    }
    public static TextView title(Context c, String s, float sp) { return text(c,s,sp,TEXT,true); }
    public static Space space(Context c,int h){ Space s=new Space(c); s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(c,h))); return s; }

    public static LinearLayout card(Context c) {
        LinearLayout v=new LinearLayout(c); v.setOrientation(LinearLayout.VERTICAL); v.setPadding(dp(c,18),dp(c,16),dp(c,18),dp(c,16));
        int alpha = DataStore.prefs(c).getInt("cardAlpha", 96);
        int a = Math.max(150, Math.min(255, (int)(255*alpha/100f)));
        v.setBackground(bg(Color.argb(a,255,255,255),dp(c,22)));
        v.setElevation(dp(c,3)); return v;
    }

    public static LinearLayout row(Context c) { LinearLayout r=new LinearLayout(c); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }

    public static TextView chip(Context c, String label, boolean selected) {
        TextView t=text(c,label,14,selected?Color.WHITE:MUTED,selected); t.setGravity(Gravity.CENTER); t.setPadding(dp(c,16),dp(c,9),dp(c,16),dp(c,9));
        t.setBackground(selected?bg(BLUE,999):strokeBg(Color.argb(235,255,255,255),dp(c,1),Color.rgb(230,236,244),999));
        return t;
    }

    public static TextView actionButton(Context c,String label, boolean primary){
        TextView b=text(c,label,15,primary?Color.WHITE:TEXT,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(c,18),dp(c,13),dp(c,18),dp(c,13));
        b.setBackground(primary?bg(BLUE,999):strokeBg(Color.WHITE,dp(c,1),LINE,999)); b.setElevation(dp(c,2)); return b;
    }

    public static LinearLayout metricCard(Context c,String label,String value,String sub){
        LinearLayout card=card(c); card.setPadding(dp(c,14),dp(c,14),dp(c,14),dp(c,14));
        card.addView(text(c,label,13,MUTED,false)); TextView v=text(c,value,24,BLUE,true); v.setPadding(0,dp(c,5),0,0); card.addView(v);
        if(sub!=null&&!sub.isEmpty()){TextView st=text(c,sub,11,MUTED,false); st.setPadding(0,dp(c,4),0,0); card.addView(st);} return card;
    }

    public static void applySystemBars(Activity a){
        a.getWindow().setStatusBarColor(Color.TRANSPARENT); a.getWindow().setNavigationBarColor(Color.rgb(248,250,253));
        if(Build.VERSION.SDK_INT>=23) a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    public static void applyBackground(Activity a, View root){
        String theme=DataStore.prefs(a).getString("bgTheme","white");
        if("custom".equals(theme)){
            String uri=DataStore.prefs(a).getString("bgUri","");
            if(!uri.isEmpty()) try(InputStream in=a.getContentResolver().openInputStream(Uri.parse(uri))){ Drawable d=Drawable.createFromStream(in,"bg"); if(d!=null){ root.setBackground(d); return; } }catch(Exception ignored){}
        }
        GradientDrawable g=new GradientDrawable(); g.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        if("mist".equals(theme)) g.setColors(new int[]{Color.rgb(245,250,255),Color.rgb(226,241,255)});
        else if("warm".equals(theme)) g.setColors(new int[]{Color.rgb(255,252,246),Color.rgb(250,239,220)});
        else if("rain".equals(theme)) g.setColors(new int[]{Color.rgb(238,245,247),Color.rgb(205,221,224)});
        else if("dark".equals(theme)) g.setColors(new int[]{Color.rgb(24,32,48),Color.rgb(9,15,28)});
        else g.setColors(new int[]{Color.WHITE,Color.rgb(247,250,253)});
        root.setBackground(g);
    }

    public static boolean isDark(Context c){ return "dark".equals(DataStore.prefs(c).getString("bgTheme","white")); }
    public static String themeLabel(Context c){
        String t=DataStore.prefs(c).getString("bgTheme","white");
        if("mist".equals(t))return "山雾浅蓝"; if("warm".equals(t))return "暖日米白"; if("rain".equals(t))return "雨落山间"; if("dark".equals(t))return "夜间深色"; if("custom".equals(t))return "自定义图片"; return "原版白色（默认）";
    }

    public static LinearLayout bottomNav(Activity a,int selected){
        LinearLayout nav=row(a); nav.setPadding(dp(a,12),dp(a,6),dp(a,12),dp(a,8)); nav.setBackground(bg(Color.argb(248,255,255,255),dp(a,24)));
        String[] labels={"专注","统计","我的"}; Class<?>[] cls={MainActivity.class,StatsActivity.class,MyActivity.class};
        for(int i=0;i<labels.length;i++){
            final int idx=i; LinearLayout item=new LinearLayout(a); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); item.setPadding(0,dp(a,7),0,dp(a,4));
            TextView icon=text(a,i==0?"●":i==1?"▮▮":"●",16,i==selected?BLUE:MUTED,true); icon.setGravity(Gravity.CENTER); item.addView(icon,new LinearLayout.LayoutParams(-1,dp(a,22)));
            TextView tx=text(a,labels[i],12,i==selected?BLUE:MUTED,i==selected); tx.setGravity(Gravity.CENTER); item.addView(tx,new LinearLayout.LayoutParams(-1,dp(a,24)));
            if(i!=selected)item.setOnClickListener(v->{Intent it=new Intent(a,cls[idx]);it.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);a.startActivity(it);});
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(a,58),1));
        }
        return nav;
    }

    public static TextView chevron(Context c){ TextView t=text(c,"›",28,MUTED,false); t.setGravity(Gravity.CENTER); return t; }

    public static LinearLayout settingsRow(Context c,String title,String sub){
        LinearLayout r=row(c); r.setPadding(dp(c,2),dp(c,11),dp(c,2),dp(c,11));
        LinearLayout textBox=new LinearLayout(c); textBox.setOrientation(LinearLayout.VERTICAL); textBox.addView(text(c,title,16,TEXT,true));
        if(sub!=null&&!sub.isEmpty())textBox.addView(text(c,sub,12,MUTED,false)); r.addView(textBox,new LinearLayout.LayoutParams(0,-2,1)); r.addView(chevron(c),new LinearLayout.LayoutParams(dp(c,30),dp(c,40))); return r;
    }

    public static void divider(Context c,LinearLayout p){ View v=new View(c);v.setBackgroundColor(LINE);p.addView(v,new LinearLayout.LayoutParams(-1,1)); }
}
