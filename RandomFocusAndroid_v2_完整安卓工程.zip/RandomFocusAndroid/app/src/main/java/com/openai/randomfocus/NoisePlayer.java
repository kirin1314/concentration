package com.openai.randomfocus;
import android.media.*;import java.util.*;
public class NoisePlayer{
 private static volatile boolean playing=false;private static Thread thread;private static AudioTrack track;public static boolean isPlaying(){return playing;}
 public static synchronized void start(String type){stop();playing=true;thread=new Thread(()->run(type));thread.start();}
 private static void run(String type){int sr=22050;int min=AudioTrack.getMinBufferSize(sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);track=new AudioTrack(AudioManager.STREAM_MUSIC,sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,4096),AudioTrack.MODE_STREAM);track.play();Random rnd=new Random();short[] buf=new short[2048];double smooth=0,phase=0;try{while(playing){for(int i=0;i<buf.length;i++){double n=rnd.nextDouble()*2-1;if("雨声".equals(type)){smooth=smooth*.82+n*.18;n=smooth;}else if("海洋".equals(type)){phase+=.0009;double amp=.25+.75*(Math.sin(phase)+1)/2;smooth=smooth*.9+n*.1;n=smooth*amp;}else if("森林".equals(type)){smooth=smooth*.94+n*.06;n=smooth*.75;}buf[i]=(short)(n*9000);}track.write(buf,0,buf.length);} }catch(Exception ignored){}finally{try{track.stop();track.release();}catch(Exception ignored){}track=null;playing=false;}}
 public static synchronized void stop(){playing=false;if(thread!=null){try{thread.join(120);}catch(Exception ignored){}thread=null;}if(track!=null){try{track.pause();track.flush();}catch(Exception ignored){}}}
}
