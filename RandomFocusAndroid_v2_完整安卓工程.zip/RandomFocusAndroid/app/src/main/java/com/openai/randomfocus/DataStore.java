package com.openai.randomfocus;

import android.content.Context;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class DataStore {
    private static final String PREF="focus";
    private static final String KEY_HISTORY="history_v2";
    private static final String KEY_SUBJECTS="subjects_v4";
    private static final String KEY_TASKS="tasks_v4";

    public static class Record { public long time; public String subject; public String task; public double minutes; public int reminders; public int distractions; public boolean completed; }
    public static class TaskItem { public long id; public String name; public String subject; public int minutes; public boolean done; public TaskItem(){} public TaskItem(long i,String n,String s,int m){id=i;name=n;subject=s;minutes=m;} }

    public static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}

    public static List<String> getSubjects(Context c){
        String raw=prefs(c).getString(KEY_SUBJECTS,"");
        ArrayList<String> out=new ArrayList<>();
        if(!raw.isEmpty()) for(String p:raw.split("\\|",-1)){String s=unb64(p);if(!s.trim().isEmpty()&&!out.contains(s))out.add(s);}
        if(out.isEmpty()){out.add("数学");out.add("英语");out.add("物化B");out.add("政治");out.add("其他");saveSubjects(c,out);} return out;
    }
    public static void saveSubjects(Context c,List<String> list){StringBuilder b=new StringBuilder();for(String s:list){String x=s==null?"":s.trim();if(x.isEmpty())continue;if(b.length()>0)b.append('|');b.append(b64(x));}prefs(c).edit().putString(KEY_SUBJECTS,b.toString()).apply();}
    public static void addSubject(Context c,String s){List<String> a=getSubjects(c);s=s==null?"":s.trim();if(!s.isEmpty()&&!a.contains(s)){a.add(s);saveSubjects(c,a);}}
    public static void renameSubject(Context c,String old,String neu){neu=neu==null?"":neu.trim();if(neu.isEmpty())return;List<String>a=getSubjects(c);int i=a.indexOf(old);if(i>=0)a.set(i,neu);saveSubjects(c,a);if(old.equals(prefs(c).getString("subject","数学")))prefs(c).edit().putString("subject",neu).apply();}
    public static void deleteSubject(Context c,String s){List<String>a=getSubjects(c);if(a.size()<=1)return;a.remove(s);saveSubjects(c,a);if(s.equals(prefs(c).getString("subject","数学")))prefs(c).edit().putString("subject",a.get(0)).apply();}

    public static List<TaskItem> getTasks(Context c){String raw=prefs(c).getString(KEY_TASKS,"");ArrayList<TaskItem> out=new ArrayList<>();if(!raw.isEmpty())for(String line:raw.split("\\n")){String[]p=line.split("\\|",-1);if(p.length<5)continue;try{TaskItem t=new TaskItem();t.id=Long.parseLong(p[0]);t.name=unb64(p[1]);t.subject=unb64(p[2]);t.minutes=Integer.parseInt(p[3]);t.done="1".equals(p[4]);out.add(t);}catch(Exception ignored){}}return out;}
    public static void saveTasks(Context c,List<TaskItem> all){StringBuilder b=new StringBuilder();for(TaskItem t:all){if(b.length()>0)b.append('\n');b.append(t.id).append('|').append(b64(t.name)).append('|').append(b64(t.subject)).append('|').append(t.minutes).append('|').append(t.done?1:0);}prefs(c).edit().putString(KEY_TASKS,b.toString()).apply();}
    public static void addTask(Context c,String name,String subject,int minutes){List<TaskItem>a=getTasks(c);a.add(new TaskItem(System.currentTimeMillis(),name,subject,Math.max(1,minutes)));saveTasks(c,a);}
    public static void removeTask(Context c,long id){List<TaskItem>a=getTasks(c);a.removeIf(t->t.id==id);saveTasks(c,a);}
    public static void toggleTask(Context c,long id){List<TaskItem>a=getTasks(c);for(TaskItem t:a)if(t.id==id)t.done=!t.done;saveTasks(c,a);}

    private static String b64(String s){return Base64.getUrlEncoder().withoutPadding().encodeToString((s==null?"":s).getBytes(StandardCharsets.UTF_8));}
    private static String unb64(String s){try{return new String(Base64.getUrlDecoder().decode(s),StandardCharsets.UTF_8);}catch(Exception e){return s==null?"":s;}}

    public static void addRecord(Context c,Record r){List<Record>all=load(c);all.add(0,r);if(all.size()>500)all=new ArrayList<>(all.subList(0,500));save(c,all);}
    public static List<Record> load(Context c){String raw=prefs(c).getString(KEY_HISTORY,"");ArrayList<Record>out=new ArrayList<>();if(!raw.isEmpty())for(String line:raw.split("\\n")){String[]p=line.split("\\|",-1);if(p.length<7)continue;try{Record r=new Record();r.time=Long.parseLong(p[0]);r.subject=unesc(p[1]);r.task=unesc(p[2]);r.minutes=Double.parseDouble(p[3]);r.reminders=Integer.parseInt(p[4]);r.distractions=Integer.parseInt(p[5]);r.completed=Boolean.parseBoolean(p[6]);out.add(r);}catch(Exception ignored){}}
        if(out.isEmpty()){String old=prefs(c).getString("history","");if(!old.isEmpty())for(String line:old.split("\\n")){String[]p=line.split("\\|",-1);if(p.length<6)continue;try{Record r=new Record();r.time=Long.parseLong(p[0]);r.subject="其他";r.task=p[1];r.minutes=Double.parseDouble(p[2]);r.reminders=Integer.parseInt(p[3]);r.distractions=Integer.parseInt(p[4]);r.completed=Boolean.parseBoolean(p[5]);out.add(r);}catch(Exception ignored){}}if(!out.isEmpty())save(c,out);}return out;}
    private static void save(Context c,List<Record>all){StringBuilder b=new StringBuilder();for(Record r:all){if(b.length()>0)b.append('\n');b.append(r.time).append('|').append(esc(r.subject)).append('|').append(esc(r.task)).append('|').append(String.format(Locale.US,"%.3f",r.minutes)).append('|').append(r.reminders).append('|').append(r.distractions).append('|').append(r.completed);}prefs(c).edit().putString(KEY_HISTORY,b.toString()).apply();}
    private static String esc(String s){return(s==null?"":s).replace("|","／").replace("\n"," ");}private static String unesc(String s){return s==null?"":s;}

    public static long startOfDay(long t){Calendar cal=Calendar.getInstance();cal.setTimeInMillis(t);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);return cal.getTimeInMillis();}
    public static long startOfStatDay(Context c,long t){int hour=prefs(c).getInt("statStartHour",0);Calendar cal=Calendar.getInstance();cal.setTimeInMillis(t);if(cal.get(Calendar.HOUR_OF_DAY)<hour)cal.add(Calendar.DAY_OF_YEAR,-1);cal.set(Calendar.HOUR_OF_DAY,hour);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);return cal.getTimeInMillis();}
    public static double minutesForDay(List<Record>all,long dayStart){long end=dayStart+86400000L;double sum=0;for(Record r:all)if(r.time>=dayStart&&r.time<end)sum+=r.minutes;return sum;}
    public static Map<String,Double> subjectMinutesForDay(Context c,List<Record>all,long dayStart){return subjectMinutesForRange(c,all,dayStart,dayStart+86400000L);}
    public static Map<String,Double> subjectMinutesForDay(List<Record>all,long dayStart){LinkedHashMap<String,Double>m=new LinkedHashMap<>();for(Record r:all)if(r.time>=dayStart&&r.time<dayStart+86400000L)m.put(r.subject,m.getOrDefault(r.subject,0.0)+r.minutes);return m;}
    public static double[] last7Days(List<Record>all){double[]v=new double[7];long today=startOfDay(System.currentTimeMillis());for(int i=0;i<7;i++)v[i]=minutesForDay(all,today-(6L-i)*86400000L);return v;}
    public static String recentHistoryText(Context c,int max){List<Record>all=load(c);if(all.isEmpty())return"还没有记录。";SimpleDateFormat df=new SimpleDateFormat("MM-dd HH:mm",Locale.getDefault());StringBuilder b=new StringBuilder();for(int i=0;i<Math.min(max,all.size());i++){Record r=all.get(i);if(b.length()>0)b.append("\n\n");b.append(df.format(new Date(r.time))).append("  ").append(r.subject).append(" · ").append(r.task).append("\n").append(String.format(Locale.getDefault(),"%.1f 分钟",r.minutes)).append("  · 提示 ").append(r.reminders).append(" 次 · 走神 ").append(r.distractions).append(" 次").append(r.completed?"  · 完成":"  · 提前结束");}return b.toString();}
    public static String buildGptSummary(Context c){List<Record>all=load(c);long today=startOfStatDay(c,System.currentTimeMillis());double todayMin=minutesForDay(all,today);Map<String,Double>subjects=subjectMinutesForDay(c,all,today);double[]week=last7Days(all);int rem=0,dis=0,sessions=0;long end=today+86400000L;for(Record r:all)if(r.time>=today&&r.time<end){rem+=r.reminders;dis+=r.distractions;sessions++;}SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault());StringBuilder b=new StringBuilder();b.append("这是我从本地专注 App 导出的考研学习数据，请把它作为今天的真实完成记录进行复盘；不要因为计划未完成而虚构完成量。\n\n日期：").append(df.format(new Date())).append('\n');b.append("今日总专注：").append(fmtHours(todayMin)).append("（").append(String.format(Locale.getDefault(),"%.0f",todayMin)).append(" 分钟）\n今日专注次数：").append(sessions).append("\n随机提示次数：").append(rem).append("，主动记录走神：").append(dis).append("\n\n分科：\n");for(Map.Entry<String,Double>e:subjects.entrySet())if(e.getValue()>0.01)b.append("- ").append(e.getKey()).append("：").append(fmtHours(e.getValue())).append('\n');b.append("\n最近 7 天总专注（由早到晚，小时）：\n");for(int i=0;i<7;i++){Date d=new Date(today-(6L-i)*86400000L);b.append(new SimpleDateFormat("MM-dd",Locale.getDefault()).format(d)).append("：").append(String.format(Locale.getDefault(),"%.2f",week[i]/60.0)).append(i==6?"":" | ");}b.append("\n\n最近学习记录：\n").append(recentHistoryText(c,12));b.append("\n\n请按：①今天完成了什么；②最大问题属于时间/状态/知识漏洞/执行中的哪一类；③明天只给少量明确优先任务；④若已有足够 7 天数据，再判断各科是否失衡。");return b.toString();}
    public static String toCsv(Context c){StringBuilder b=new StringBuilder("time,subject,task,minutes,reminders,distractions,completed\n");SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);for(Record r:load(c))b.append(csv(df.format(new Date(r.time)))).append(',').append(csv(r.subject)).append(',').append(csv(r.task)).append(',').append(String.format(Locale.US,"%.2f",r.minutes)).append(',').append(r.reminders).append(',').append(r.distractions).append(',').append(r.completed).append('\n');return b.toString();}
    public static String toJson(Context c){StringBuilder b=new StringBuilder("{\n  \"records\": [\n");List<Record>all=load(c);for(int i=0;i<all.size();i++){Record r=all.get(i);b.append("    {\"time\":").append(r.time).append(",\"subject\":\"").append(json(r.subject)).append("\",\"task\":\"").append(json(r.task)).append("\",\"minutes\":").append(String.format(Locale.US,"%.3f",r.minutes)).append(",\"reminders\":").append(r.reminders).append(",\"distractions\":").append(r.distractions).append(",\"completed\":").append(r.completed).append("}");if(i<all.size()-1)b.append(',');b.append('\n');}b.append("  ]\n}");return b.toString();}
    private static String csv(String s){return"\""+(s==null?"":s.replace("\"","\"\""))+"\"";}private static String json(String s){return(s==null?"":s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");}
    public static String fmtHours(double min){int total=(int)Math.round(min),h=total/60,m=total%60;return h>0?h+" 小时 "+m+" 分":m+" 分";}
    public static int countForDay(List<Record>all,long dayStart){int n=0;for(Record r:all)if(r.time>=dayStart&&r.time<dayStart+86400000L)n++;return n;}
    public static double totalMinutes(List<Record>all){double s=0;for(Record r:all)s+=r.minutes;return s;}
    public static int streakDays(List<Record>all){if(all.isEmpty())return 0;long day=startOfDay(System.currentTimeMillis());int streak=0;for(int i=0;i<3650;i++){if(minutesForDay(all,day)>.01){streak++;day-=86400000L;}else if(i==0)day-=86400000L;else break;}return streak;}
    public static Map<String,Double> subjectMinutesForRange(Context c,List<Record>all,long start,long end){LinkedHashMap<String,Double>m=new LinkedHashMap<>();for(String s:getSubjects(c))m.put(s,0.0);for(Record r:all)if(r.time>=start&&r.time<end)m.put(r.subject,m.getOrDefault(r.subject,0.0)+r.minutes);return m;}
    public static Map<String,Double> subjectMinutesForRange(List<Record>all,long start,long end){LinkedHashMap<String,Double>m=new LinkedHashMap<>();for(Record r:all)if(r.time>=start&&r.time<end)m.put(r.subject,m.getOrDefault(r.subject,0.0)+r.minutes);return m;}
    public static double[] last84Days(List<Record>all){double[]out=new double[84];long today=startOfDay(System.currentTimeMillis());for(int i=0;i<84;i++)out[i]=minutesForDay(all,today-(83L-i)*86400000L);return out;}
    public static double[] hourlyDistribution(List<Record>all,int days){double[]out=new double[24];long now=System.currentTimeMillis(),start=startOfDay(now)-(Math.max(1,days)-1L)*86400000L;Calendar cal=Calendar.getInstance();for(Record r:all){if(r.time<start||r.time>now)continue;cal.setTimeInMillis(r.time);out[cal.get(Calendar.HOUR_OF_DAY)]+=r.minutes;}return out;}
}
