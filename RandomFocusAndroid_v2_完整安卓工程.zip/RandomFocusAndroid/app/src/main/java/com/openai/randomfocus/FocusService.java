package com.openai.randomfocus;

import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.*;
import java.util.*;

public class FocusService extends Service {
    public static final String ACTION_STATE = "com.openai.randomfocus.STATE";
    public static final String CMD_START = "START", CMD_PAUSE = "PAUSE", CMD_RESUME = "RESUME", CMD_DISTRACT = "DISTRACT", CMD_STOP = "STOP";
    private static final String CH_ID = "focus_timer_v3";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private long endAt, remainingMs, totalMs, nextBeepAt, pauseStartedAt, nextPauseReminderAt;
    private int minGapSec, maxGapSec, reminders, distractions, volume = 60, tone = ToneGenerator.TONE_PROP_BEEP;
    private String task = "专注学习", subject = "数学";
    private boolean running = false, paused = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long now=System.currentTimeMillis();
            if (running && !paused) {
                remainingMs=Math.max(0,endAt-now);
                if(now>=nextBeepAt && remainingMs>0){ beep(); reminders++; scheduleNextBeep(); }
                if(remainingMs<=0){ saveRecord(true); completionBeep(); stopSession(); return; }
            } else if(running && paused && DataStore.prefs(FocusService.this).getBoolean("pauseReminder",false)) {
                if(nextPauseReminderAt>0 && now>=nextPauseReminderAt){beep();nextPauseReminderAt=now+DataStore.prefs(FocusService.this).getInt("pauseReminderMin",10)*60000L;}
            }
            if(running){broadcast();updateNotification();}
            handler.postDelayed(this,1000);
        }
    };

    @Override public void onCreate(){ super.onCreate(); createChannel(); handler.post(tick); }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null) return START_NOT_STICKY; String cmd=intent.getStringExtra("cmd");
        if(CMD_START.equals(cmd)){
            task=nonNull(intent.getStringExtra("task"),"专注学习"); subject=nonNull(intent.getStringExtra("subject"),"数学");
            long durationMin=intent.getLongExtra("durationMin",40); minGapSec=Math.max(5,intent.getIntExtra("minGapSec",180)); maxGapSec=Math.max(minGapSec,intent.getIntExtra("maxGapSec",300));
            volume=intent.getIntExtra("volume",60); String sound=intent.getStringExtra("sound"); tone="高音".equals(sound)?ToneGenerator.TONE_PROP_BEEP2:"柔和".equals(sound)?ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD:ToneGenerator.TONE_PROP_BEEP;
            reminders=distractions=0; totalMs=durationMin*60000L;remainingMs=totalMs;endAt=System.currentTimeMillis()+remainingMs;running=true;paused=false;pauseStartedAt=0;nextPauseReminderAt=0;scheduleNextBeep();startForeground(1,buildNotification());broadcast();
        }else if(CMD_PAUSE.equals(cmd)&&running&&!paused){remainingMs=Math.max(0,endAt-System.currentTimeMillis());paused=true;pauseStartedAt=System.currentTimeMillis();nextPauseReminderAt=pauseStartedAt+DataStore.prefs(this).getInt("pauseReminderMin",10)*60000L;broadcast();updateNotification();}
        else if(CMD_RESUME.equals(cmd)&&running&&paused){endAt=System.currentTimeMillis()+remainingMs;paused=false;pauseStartedAt=0;nextPauseReminderAt=0;scheduleNextBeep();broadcast();updateNotification();}
        else if(CMD_DISTRACT.equals(cmd)&&running){distractions++;broadcast();updateNotification();}
        else if(CMD_STOP.equals(cmd)&&running){saveRecord(false);stopSession();}
        return START_NOT_STICKY;
    }

    private String nonNull(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    private void scheduleNextBeep(){int gap=minGapSec+random.nextInt(Math.max(1,maxGapSec-minGapSec+1));nextBeepAt=System.currentTimeMillis()+gap*1000L;}
    private void beep(){try{ToneGenerator tg=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,Math.max(0,Math.min(100,volume)));tg.startTone(tone,140);handler.postDelayed(tg::release,260);}catch(Exception ignored){}}
    private void completionBeep(){try{ToneGenerator tg=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,Math.max(0,Math.min(100,volume)));tg.startTone(ToneGenerator.TONE_PROP_ACK,450);handler.postDelayed(tg::release,700);}catch(Exception ignored){}}
    private void broadcast(){Intent i=new Intent(ACTION_STATE);i.setPackage(getPackageName());i.putExtra("running",running);i.putExtra("paused",paused);i.putExtra("remainingMs",remainingMs);i.putExtra("reminders",reminders);i.putExtra("distractions",distractions);i.putExtra("subject",subject);i.putExtra("task",task);sendBroadcast(i);}
    private PendingIntent commandPi(String cmd,int request){Intent i=new Intent(this,FocusService.class);i.putExtra("cmd",cmd);return PendingIntent.getService(this,request,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
    private void createChannel(){NotificationManager nm=getSystemService(NotificationManager.class);NotificationChannel ch=new NotificationChannel(CH_ID,"专注计时",NotificationManager.IMPORTANCE_LOW);ch.setDescription("专注计时与注意力提醒");ch.setSound(null,null);nm.createNotificationChannel(ch);}
    private Notification buildNotification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification.Builder b=new Notification.Builder(this,CH_ID).setSmallIcon(R.drawable.ic_notification).setContentTitle(paused?"专注已暂停":subject+" · "+task).setContentText(format(remainingMs)+" · 提示 "+reminders+" · 走神 "+distractions).setContentIntent(pi).setOngoing(running).setOnlyAlertOnce(true);b.addAction(new Notification.Action.Builder(null,paused?"继续":"暂停",commandPi(paused?CMD_RESUME:CMD_PAUSE,2)).build());b.addAction(new Notification.Action.Builder(null,"走神 +1",commandPi(CMD_DISTRACT,3)).build());b.addAction(new Notification.Action.Builder(null,"结束",commandPi(CMD_STOP,4)).build());return b.build();}
    private void updateNotification(){if(running)getSystemService(NotificationManager.class).notify(1,buildNotification());}
    private void saveRecord(boolean completed){DataStore.Record r=new DataStore.Record();r.time=System.currentTimeMillis();r.subject=subject;r.task=task;r.minutes=Math.max(0,(totalMs-remainingMs)/60000.0);r.reminders=reminders;r.distractions=distractions;r.completed=completed;boolean ignore=DataStore.prefs(this).getBoolean("ignoreShort",false);int threshold=DataStore.prefs(this).getInt("ignoreShortMin",2);if(!ignore||r.minutes>=threshold)DataStore.addRecord(this,r);}
    private void stopSession(){running=false;paused=false;remainingMs=0;broadcast();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    private String format(long ms){long s=Math.max(0,ms/1000),h=s/3600,m=(s%3600)/60,sec=s%60;return h>0?String.format(Locale.getDefault(),"%02d:%02d:%02d",h,m,sec):String.format(Locale.getDefault(),"%02d:%02d",m,sec);}
    @Override public void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
