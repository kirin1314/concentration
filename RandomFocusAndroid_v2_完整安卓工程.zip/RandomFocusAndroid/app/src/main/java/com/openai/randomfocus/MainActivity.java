package com.openai.randomfocus;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText taskInput,durationInput,minGapInput,maxGapInput,goalInput;
    TextView timerText,statusText,statsText,historyText,todayTotalText,todaySubjectsText,goalText;
    Button startButton,pauseButton;
    Spinner subjectSpinner,soundSpinner;
    SeekBar volumeSeek;
    ProgressBar dailyProgress;
    WeekChartView weekChart;
    Switch darkModeSwitch;
    boolean running=false,paused=false;
    final String[] subjects={"数学","英语","物化B","政治","其他"};

    private final BroadcastReceiver receiver=new BroadcastReceiver(){ @Override public void onReceive(Context context,Intent i){
        running=i.getBooleanExtra("running",false); paused=i.getBooleanExtra("paused",false);
        long remaining=i.getLongExtra("remainingMs",0); int r=i.getIntExtra("reminders",0),d=i.getIntExtra("distractions",0);
        timerText.setText(format(remaining)); statusText.setText(!running?"准备开始":paused?"已暂停":"专注中 · 提示音响起时只检查是否走神");
        statsText.setText("提示 "+r+" 次    ·    走神 "+d+" 次"); startButton.setEnabled(!running); pauseButton.setEnabled(running); pauseButton.setText(paused?"继续":"暂停");
        if(!running) refreshDashboard();
    }};

    @Override protected void onCreate(Bundle savedInstanceState){
        boolean dark = getSharedPreferences("focus",MODE_PRIVATE).getBoolean("darkMode",false);
        setTheme(dark ? R.style.AppThemeDark : R.style.AppTheme);
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        taskInput=findViewById(R.id.taskInput); durationInput=findViewById(R.id.durationInput); minGapInput=findViewById(R.id.minGapInput); maxGapInput=findViewById(R.id.maxGapInput); goalInput=findViewById(R.id.goalInput);
        timerText=findViewById(R.id.timerText); statusText=findViewById(R.id.statusText); statsText=findViewById(R.id.statsText); historyText=findViewById(R.id.historyText); todayTotalText=findViewById(R.id.todayTotalText); todaySubjectsText=findViewById(R.id.todaySubjectsText); goalText=findViewById(R.id.goalText);
        startButton=findViewById(R.id.startButton); pauseButton=findViewById(R.id.pauseButton); subjectSpinner=findViewById(R.id.subjectSpinner); soundSpinner=findViewById(R.id.soundSpinner); volumeSeek=findViewById(R.id.volumeSeek); dailyProgress=findViewById(R.id.dailyProgress); weekChart=findViewById(R.id.weekChart); darkModeSwitch=findViewById(R.id.darkModeSwitch);
        Button distract=findViewById(R.id.distractButton),stop=findViewById(R.id.stopButton),saveGoal=findViewById(R.id.saveGoalButton),shareGpt=findViewById(R.id.shareGptButton),exportCsv=findViewById(R.id.exportCsvButton),exportJson=findViewById(R.id.exportJsonButton);

        subjectSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,subjects));
        soundSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"标准","柔和","高音"}));
        volumeSeek.setMax(100); volumeSeek.setProgress(DataStore.prefs(this).getInt("volume",70));
        darkModeSwitch.setChecked(dark); darkModeSwitch.setOnCheckedChangeListener((b,checked)->{DataStore.prefs(this).edit().putBoolean("darkMode",checked).apply(); recreate();});
        goalInput.setText(String.valueOf(DataStore.prefs(this).getInt("dailyGoalMin",600)));
        durationInput.setText(String.valueOf(DataStore.prefs(this).getInt("durationMin",90))); minGapInput.setText(String.valueOf(DataStore.prefs(this).getInt("minGapSec",45))); maxGapInput.setText(String.valueOf(DataStore.prefs(this).getInt("maxGapSec",150)));

        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);
        startButton.setOnClickListener(v->startFocus()); pauseButton.setOnClickListener(v->send(paused?FocusService.CMD_RESUME:FocusService.CMD_PAUSE)); distract.setOnClickListener(v->send(FocusService.CMD_DISTRACT));
        stop.setOnClickListener(v->{if(running)new AlertDialog.Builder(this).setTitle("结束本次？").setMessage("会保存已经完成的专注时间。") .setNegativeButton("取消",null).setPositiveButton("结束",(d,w)->send(FocusService.CMD_STOP)).show();});
        saveGoal.setOnClickListener(v->saveGoal()); shareGpt.setOnClickListener(v->shareToChatGPT()); exportCsv.setOnClickListener(v->shareText("focus-data.csv","text/csv",DataStore.toCsv(this))); exportJson.setOnClickListener(v->shareText("focus-data.json","application/json",DataStore.toJson(this)));
        refreshDashboard();
    }

    private void startFocus(){
        try{
            long mins=Long.parseLong(durationInput.getText().toString().trim()); int mn=Integer.parseInt(minGapInput.getText().toString().trim()); int mx=Integer.parseInt(maxGapInput.getText().toString().trim()); if(mins<=0||mn<5||mx<mn)throw new Exception();
            String task=taskInput.getText().toString().trim(); if(task.isEmpty())task="考研学习"; String subject=(String)subjectSpinner.getSelectedItem(); String sound=(String)soundSpinner.getSelectedItem(); int volume=volumeSeek.getProgress();
            DataStore.prefs(this).edit().putInt("durationMin",(int)mins).putInt("minGapSec",mn).putInt("maxGapSec",mx).putInt("volume",volume).apply();
            Intent i=new Intent(this,FocusService.class); i.putExtra("cmd",FocusService.CMD_START); i.putExtra("task",task); i.putExtra("subject",subject); i.putExtra("durationMin",mins); i.putExtra("minGapSec",mn); i.putExtra("maxGapSec",mx); i.putExtra("volume",volume); i.putExtra("sound",sound); startForegroundService(i); timerText.setText(format(mins*60000L));
        }catch(Exception e){ Toast.makeText(this,"请检查：时长 > 0，最短间隔 ≥ 5 秒，最长间隔 ≥ 最短间隔",Toast.LENGTH_LONG).show(); }
    }

    private void send(String cmd){ Intent i=new Intent(this,FocusService.class); i.putExtra("cmd",cmd); startService(i); }
    private void saveGoal(){ try{int g=Integer.parseInt(goalInput.getText().toString().trim()); if(g<1)throw new Exception(); DataStore.prefs(this).edit().putInt("dailyGoalMin",g).apply(); refreshDashboard(); Toast.makeText(this,"今日目标已保存",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"请输入正确的分钟数",Toast.LENGTH_SHORT).show();} }

    private void refreshDashboard(){
        List<DataStore.Record> all=DataStore.load(this); long today=DataStore.startOfDay(System.currentTimeMillis()); double total=DataStore.minutesForDay(all,today); int goal=DataStore.prefs(this).getInt("dailyGoalMin",600);
        todayTotalText.setText(DataStore.fmtHours(total)); int pct=(int)Math.min(100,Math.round(total*100.0/Math.max(1,goal))); dailyProgress.setProgress(pct); goalText.setText("今日目标 "+DataStore.fmtHours(goal)+" · 已完成 "+pct+"%");
        Map<String,Double> sm=DataStore.subjectMinutesForDay(all,today); StringBuilder sb=new StringBuilder(); for(String s:subjects){double m=sm.getOrDefault(s,0.0); if(m>0.01){if(sb.length()>0)sb.append("   "); sb.append(s).append(" ").append(DataStore.fmtHours(m));}} todaySubjectsText.setText(sb.length()==0?"今天还没有专注记录":sb.toString());
        historyText.setText(DataStore.recentHistoryText(this,10)); weekChart.setValues(DataStore.last7Days(all));
    }

    private void shareToChatGPT(){
        String text=DataStore.buildGptSummary(this); Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); i.setPackage("com.openai.chatgpt");
        try{startActivity(i);}catch(Exception e){ i.setPackage(null); startActivity(Intent.createChooser(i,"发送学习数据到 ChatGPT")); }
    }

    private void shareText(String title,String type,String content){ Intent i=new Intent(Intent.ACTION_SEND); i.setType(type); i.putExtra(Intent.EXTRA_SUBJECT,title); i.putExtra(Intent.EXTRA_TEXT,content); startActivity(Intent.createChooser(i,"导出 "+title)); }
    private String format(long ms){long s=Math.max(0,ms/1000),h=s/3600,m=(s%3600)/60,sec=s%60;return String.format(Locale.getDefault(),"%02d:%02d:%02d",h,m,sec);}

    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter(FocusService.ACTION_STATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f); refreshDashboard();}
    @Override protected void onStop(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onStop();}
}
