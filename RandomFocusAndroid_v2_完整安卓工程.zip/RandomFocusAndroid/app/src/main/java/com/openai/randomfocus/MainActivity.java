package com.openai.randomfocus;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private TimerRingView timerRing;
    private TextView primaryButton, modeText, bgText, subjectSelected;
    private LinearLayout metricsRow, subjectRow;
    private boolean running=false, paused=false;
    private long remainingMs=0,totalMs=40*60*1000L;
    private String subject="数学";
    private final String[] subjects={"数学","英语","物化B","政治","其他"};

    private final BroadcastReceiver receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
        running=i.getBooleanExtra("running",false); paused=i.getBooleanExtra("paused",false); remainingMs=i.getLongExtra("remainingMs",0);
        String s=i.getStringExtra("subject"); if(s!=null)subject=s;
        refreshTimer(); refreshMetrics();
    }};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); UiKit.applySystemBars(this);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);
        buildScreen();
    }

    private void buildScreen(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); UiKit.applyBackground(this,root);
        FrameLayout contentHolder=new FrameLayout(this); root.addView(contentHolder,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); contentHolder.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(UiKit.dp(this,20),UiKit.dp(this,14),UiKit.dp(this,20),UiKit.dp(this,24)); scroll.addView(page);

        // Header
        LinearLayout header=UiKit.row(this); LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(UiKit.title(this,"专注",34)); titles.addView(UiKit.text(this,"专注当下，稳定前进",14,UiKit.MUTED,false));
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView bgBtn=UiKit.actionButton(this,"背景",false); bgBtn.setOnClickListener(v->startActivity(new Intent(this,BackgroundActivity.class))); header.addView(bgBtn,new LinearLayout.LayoutParams(UiKit.dp(this,72),UiKit.dp(this,48)));
        TextView setBtn=UiKit.actionButton(this,"设置",false); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(UiKit.dp(this,72),UiKit.dp(this,48));sp.setMargins(UiKit.dp(this,8),0,0,0);header.addView(setBtn,sp);setBtn.setOnClickListener(v->startActivity(new Intent(this,MyActivity.class)));
        page.addView(header);

        page.addView(UiKit.space(this,10));
        // Subject chips
        subjectRow=UiKit.row(this); rebuildSubjects(); HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.addView(subjectRow);page.addView(hsv,new LinearLayout.LayoutParams(-1,UiKit.dp(this,52)));

        // Timer
        timerRing=new TimerRingView(this); timerRing.setOnClickListener(v->{if("打开专注模式设置".equals(DataStore.prefs(this).getString("ringAction","开始/暂停专注")))startActivity(new Intent(this,ModeActivity.class));else toggleStartPause();}); page.addView(timerRing,new LinearLayout.LayoutParams(-1,UiKit.dp(this,330)));

        modeText=UiKit.title(this,"🍅  "+modeLabel()+"  ›",17); modeText.setGravity(Gravity.CENTER); modeText.setOnClickListener(v->startActivity(new Intent(this,ModeActivity.class))); page.addView(modeText,new LinearLayout.LayoutParams(-1,UiKit.dp(this,38)));
        TextView modeSub=UiKit.text(this,modeSub(),13,UiKit.MUTED,false);modeSub.setGravity(Gravity.CENTER);page.addView(modeSub,new LinearLayout.LayoutParams(-1,UiKit.dp(this,30)));

        // Controls
        LinearLayout controls=UiKit.row(this); controls.setGravity(Gravity.CENTER);
        TextView noise=UiKit.actionButton(this,"♫  白噪音",false); noise.setOnClickListener(v->startActivity(new Intent(this,NoiseActivity.class))); controls.addView(noise,new LinearLayout.LayoutParams(0,UiKit.dp(this,52),1));
        primaryButton=UiKit.actionButton(this,"▶  开始专注",true); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,UiKit.dp(this,58),1.25f);cp.setMargins(UiKit.dp(this,10),0,UiKit.dp(this,10),0);controls.addView(primaryButton,cp);primaryButton.setOnClickListener(v->toggleStartPause());
        TextView end=UiKit.actionButton(this,"■  结束",false); end.setOnClickListener(v->endSession()); controls.addView(end,new LinearLayout.LayoutParams(0,UiKit.dp(this,52),1)); page.addView(controls);
        TextView distract=UiKit.text(this,"走神了？点这里 +1",12,UiKit.MUTED,false);distract.setGravity(Gravity.CENTER);distract.setPadding(0,UiKit.dp(this,8),0,0);distract.setOnClickListener(v->send(FocusService.CMD_DISTRACT));page.addView(distract,new LinearLayout.LayoutParams(-1,UiKit.dp(this,34)));

        page.addView(UiKit.space(this,12));
        metricsRow=UiKit.row(this); page.addView(metricsRow,new LinearLayout.LayoutParams(-1,UiKit.dp(this,120))); refreshMetrics();

        page.addView(UiKit.space(this,14));
        LinearLayout quick=UiKit.card(this); LinearLayout qh=UiKit.row(this);qh.addView(UiKit.title(this,"快捷功能",18),new LinearLayout.LayoutParams(0,-2,1));qh.addView(UiKit.text(this,"高效专注，从这里开始",12,UiKit.MUTED,false));quick.addView(qh);
        LinearLayout qrow=UiKit.row(this);qrow.setPadding(0,UiKit.dp(this,10),0,0);
        qrow.addView(quickButton("▮▮\n数据统计",()->startActivity(new Intent(this,StatsActivity.class))),new LinearLayout.LayoutParams(0,UiKit.dp(this,84),1));
        qrow.addView(quickButton("◎\n专注模式",()->startActivity(new Intent(this,ModeActivity.class))),new LinearLayout.LayoutParams(0,UiKit.dp(this,84),1));
        qrow.addView(quickButton("◉\n背景与外观",()->startActivity(new Intent(this,BackgroundActivity.class))),new LinearLayout.LayoutParams(0,UiKit.dp(this,84),1));
        qrow.addView(quickButton("♫\n白噪音",()->startActivity(new Intent(this,NoiseActivity.class))),new LinearLayout.LayoutParams(0,UiKit.dp(this,84),1)); quick.addView(qrow);page.addView(quick);

        page.addView(UiKit.space(this,12));
        LinearLayout bgCard=UiKit.card(this);LinearLayout br=UiKit.row(this); TextView icon=UiKit.text(this,"▧",28,UiKit.BLUE,false); icon.setGravity(Gravity.CENTER);br.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,52)));
        LinearLayout bt=new LinearLayout(this);bt.setOrientation(LinearLayout.VERTICAL);bt.addView(UiKit.text(this,"背景："+UiKit.themeLabel(this),16,UiKit.TEXT,true));bt.addView(UiKit.text(this,"可自定义背景，默认为原版白色",12,UiKit.MUTED,false));br.addView(bt,new LinearLayout.LayoutParams(0,-2,1));br.addView(UiKit.chevron(this),new LinearLayout.LayoutParams(UiKit.dp(this,32),UiKit.dp(this,52)));bgCard.addView(br);bgCard.setOnClickListener(v->startActivity(new Intent(this,BackgroundActivity.class)));page.addView(bgCard);

        root.addView(UiKit.bottomNav(this,0),new LinearLayout.LayoutParams(-1,UiKit.dp(this,64)));
        setContentView(root); refreshTimer();
    }

    private View quickButton(String label,Runnable action){ TextView b=UiKit.text(this,label,13,UiKit.TEXT,true);b.setGravity(Gravity.CENTER);b.setBackground(UiKit.bg(android.graphics.Color.rgb(248,251,255),UiKit.dp(this,18)));b.setOnClickListener(v->action.run());return b; }

    private void rebuildSubjects(){
        subjectRow.removeAllViews(); String saved=DataStore.prefs(this).getString("subject","数学");subject=saved;
        for(String s:subjects){TextView ch=UiKit.chip(this,s,s.equals(saved));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,42));lp.setMargins(0,0,UiKit.dp(this,8),0);subjectRow.addView(ch,lp);ch.setOnClickListener(v->{subject=s;DataStore.prefs(this).edit().putString("subject",s).apply();rebuildSubjects();refreshTimer();});}
    }

    private void refreshTimer(){
        int mins=DataStore.prefs(this).getInt("focusMin",40); if(!running){totalMs=mins*60000L;remainingMs=totalMs;} else if(totalMs<=0)totalMs=mins*60000L;
        timerRing.setState(remainingMs,totalMs,subject,paused); primaryButton.setText(!running?"▶  开始专注":paused?"▶  继续":"Ⅱ  暂停");
    }

    private void refreshMetrics(){
        if(metricsRow==null)return;metricsRow.removeAllViews();List<DataStore.Record>all=DataStore.load(this);long today=DataStore.startOfStatDay(this,System.currentTimeMillis());double min=DataStore.minutesForDay(all,today);int cnt=DataStore.countForDay(all,today);int streak=DataStore.streakDays(all);
        addMetric(metricsRow,"今日专注",DataStore.fmtHours(min),"今日真实记录");addMetric(metricsRow,"今日周期",cnt+" 个","专注次数");addMetric(metricsRow,"连续专注",streak+" 天","保持节奏");
    }
    private void addMetric(LinearLayout row,String l,String v,String s){LinearLayout c=UiKit.metricCard(this,l,v,s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(0,0,UiKit.dp(this,8),0);row.addView(c,lp);}

    private String modeLabel(){return DataStore.prefs(this).getString("mode","随机提示音");}
    private String modeSub(){String m=modeLabel();int f=DataStore.prefs(this).getInt("focusMin",40);int br=DataStore.prefs(this).getInt("breakMin",5);return "番茄时钟法".equals(m)?"专注 "+f+" 分钟 · 休息 "+br+" 分钟":"随机提示音".equals(m)?"随机提醒 · 检查是否走神":"低频提醒 · 减少分心";}

    private void toggleStartPause(){ if(!running)startFocus(); else send(paused?FocusService.CMD_RESUME:FocusService.CMD_PAUSE); }
    private void startFocus(){
        int mins=DataStore.prefs(this).getInt("focusMin",40),mn=DataStore.prefs(this).getInt("minGapSec",180),mx=DataStore.prefs(this).getInt("maxGapSec",300),vol=DataStore.prefs(this).getInt("volume",60);String mode=modeLabel();
        if("番茄时钟法".equals(mode)){mn=mins*60+60;mx=mn+30;} else if("防走神模式".equals(mode)){mn=Math.max(300,mn);mx=Math.max(mn+60,mx*2);}
        Intent i=new Intent(this,FocusService.class);i.putExtra("cmd",FocusService.CMD_START);i.putExtra("task","专注学习");i.putExtra("subject",subject);i.putExtra("durationMin",(long)mins);i.putExtra("minGapSec",mn);i.putExtra("maxGapSec",mx);i.putExtra("volume",vol);i.putExtra("sound",DataStore.prefs(this).getString("sound","柔和"));startForegroundService(i);running=true;paused=false;totalMs=mins*60000L;remainingMs=totalMs;refreshTimer();
    }
    private void endSession(){if(!running){Toast.makeText(this,"当前没有进行中的专注",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("结束本次专注？").setMessage("已完成的时间会保存到统计中。").setNegativeButton("继续专注",null).setPositiveButton("结束",(d,w)->send(FocusService.CMD_STOP)).show();}
    private void send(String cmd){Intent i=new Intent(this,FocusService.class);i.putExtra("cmd",cmd);startService(i);}

    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter(FocusService.ACTION_STATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);refreshMetrics();}
    @Override protected void onStop(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onStop();}
    @Override protected void onResume(){super.onResume(); if(modeText!=null){modeText.setText("🍅  "+modeLabel()+"  ›");} if(bgText!=null)bgText.setText(UiKit.themeLabel(this));}
}
