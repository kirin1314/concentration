package com.openai.randomfocus;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class WebDavSync {
    public interface Callback { void done(boolean ok, String message); }

    private static String fileUrl(Context c){
        String base=DataStore.prefs(c).getString("webdavUrl","").trim();
        if(base.endsWith("/")) return base+"concentration-backup.txt";
        return base+"/concentration-backup.txt";
    }
    private static HttpURLConnection open(Context c,String method) throws Exception{
        URL u=new URL(fileUrl(c));
        HttpURLConnection h=(HttpURLConnection)u.openConnection();
        h.setRequestMethod(method);h.setConnectTimeout(12000);h.setReadTimeout(16000);h.setUseCaches(false);
        h.setRequestProperty("User-Agent","Concentration/4.1");
        String user=DataStore.prefs(c).getString("webdavUser","");
        String pass=DataStore.prefs(c).getString("webdavPassword","");
        if(!user.isEmpty()||!pass.isEmpty()){
            String basic=Base64.getEncoder().encodeToString((user+":"+pass).getBytes(StandardCharsets.UTF_8));
            h.setRequestProperty("Authorization","Basic "+basic);
        }
        return h;
    }
    private static void post(Callback cb,boolean ok,String msg){if(cb==null)return;new Handler(Looper.getMainLooper()).post(()->cb.done(ok,msg));}
    public static boolean configured(Context c){String u=DataStore.prefs(c).getString("webdavUrl","").trim();return u.startsWith("http://")||u.startsWith("https://");}
    public static void uploadBackupAsync(Context c,Callback cb){Context app=c.getApplicationContext();new Thread(()->{
        if(!configured(app)){post(cb,false,"请先配置 WebDAV 地址");return;}
        HttpURLConnection h=null;try{
            byte[] data=DataStore.exportBackup(app).getBytes(StandardCharsets.UTF_8);h=open(app,"PUT");h.setDoOutput(true);h.setRequestProperty("Content-Type","text/plain; charset=utf-8");h.setFixedLengthStreamingMode(data.length);try(OutputStream os=h.getOutputStream()){os.write(data);}int code=h.getResponseCode();if(code>=200&&code<300){DataStore.prefs(app).edit().putLong("lastSyncAt",System.currentTimeMillis()).apply();post(cb,true,"已上传到 WebDAV");}else post(cb,false,"上传失败：HTTP "+code);
        }catch(Exception e){post(cb,false,"上传失败："+friendly(e));}finally{if(h!=null)h.disconnect();}
    }).start();}
    public static void downloadBackupAsync(Context c,Callback cb){Context app=c.getApplicationContext();new Thread(()->{
        if(!configured(app)){post(cb,false,"请先配置 WebDAV 地址");return;}
        HttpURLConnection h=null;try{h=open(app,"GET");int code=h.getResponseCode();if(code<200||code>=300){post(cb,false,"下载失败：HTTP "+code);return;}StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream(),StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line).append('\n');}boolean ok=DataStore.importBackup(app,b.toString());if(ok){DataStore.prefs(app).edit().putLong("lastSyncAt",System.currentTimeMillis()).apply();post(cb,true,"已从 WebDAV 恢复数据");}else post(cb,false,"云端文件不是有效的专注备份");
        }catch(Exception e){post(cb,false,"下载失败："+friendly(e));}finally{if(h!=null)h.disconnect();}
    }).start();}
    public static void testAsync(Context c,Callback cb){Context app=c.getApplicationContext();new Thread(()->{
        if(!configured(app)){post(cb,false,"请先配置 WebDAV 地址");return;}HttpURLConnection h=null;try{h=open(app,"HEAD");int code=h.getResponseCode();if(code==405||code==501){post(cb,true,"地址可用；服务器不支持 HEAD，可直接尝试同步");return;}post(cb,code>=200&&code<500,code>=200&&code<500?"WebDAV 服务器已响应（HTTP "+code+"）":"连接失败：HTTP "+code);}catch(Exception e){post(cb,false,"连接失败："+friendly(e));}finally{if(h!=null)h.disconnect();}
    }).start();}
    private static String friendly(Exception e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():m;}
}
