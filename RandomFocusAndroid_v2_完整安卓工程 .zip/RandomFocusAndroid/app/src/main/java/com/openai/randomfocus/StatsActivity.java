package com.openai.randomfocus;

import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import java.util.*;

public class StatsActivity extends Activity{
 @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applySystemBars(this);build();}
 private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);UiKit.applyBackground(this,root);ScrollView scroll=new ScrollView(this);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(UiKit.dp(this,20),UiKit.dp(this,22),UiKit.dp(this,20),UiKit.dp(this,24));scroll.addView(page);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout head=UiKit.row(this);LinearLayout tt=new LinearLayout(this);tt.setOrientation(LinearLayout.VERTICAL);tt.addView(UiKit.title(this,"数据统计",30));tt.addView(UiKit.text(this,"见证每一次专注的积累",13,UiKit.mutedColor(this),false));head.addView(tt,new LinearLayout.LayoutParams(0,-2,1));TextView period=UiKit.actionButton(this,"日  周  月  年",false);head.addView(period,new LinearLayout.LayoutParams(UiKit.dp(this,145),UiKit.dp(this,46)));page.addView(head);
  page.addView(UiKit.space(this,14));
  List<DataStore.Record> all=DataStore.load(this);long today=DataStore.startOfStatDay(this,System.currentTimeMillis());double todayMin=DataStore.minutesForDay(all,today);int todayCnt=DataStore.countForDay(all,today);double week=0;for(double v:DataStore.last7Days(all))week+=v;int streak=DataStore.streakDays(all);
  LinearLayout a=UiKit.row(this);metric(a,"今日专注",DataStore.fmtHours(todayMin),"今日真实记录");metric(a,"今日周期",todayCnt+" 个","专注次数");page.addView(a,new LinearLayout.LayoutParams(-1,UiKit.dp(this,118)));page.addView(UiKit.space(this,9));LinearLayout c=UiKit.row(this);metric(c,"本周总时长",DataStore.fmtHours(week),"最近 7 天");metric(c,"连续天数",streak+" 天","保持专注");page.addView(c,new LinearLayout.LayoutParams(-1,UiKit.dp(this,118)));

  page.addView(UiKit.space(this,14));LinearLayout detail=UiKit.card(this);LinearLayout dh=UiKit.row(this);dh.addView(UiKit.title(this,"专注详情",19),new LinearLayout.LayoutParams(0,-2,1));dh.addView(UiKit.text(this,"最近 7 天",12,UiKit.mutedColor(this),false));detail.addView(dh);SubjectDonutView donut=new SubjectDonutView(this);long start=today-6L*24*60*60*1000;donut.setValues(DataStore.subjectMinutesForRange(this,all,start,today+24L*60*60*1000));detail.addView(donut,new LinearLayout.LayoutParams(-1,UiKit.dp(this,250)));page.addView(detail);

  page.addView(UiKit.space(this,14));LinearLayout best=UiKit.card(this);LinearLayout bh=UiKit.row(this);bh.addView(UiKit.title(this,"最佳专注时间",19),new LinearLayout.LayoutParams(0,-2,1));bh.addView(UiKit.text(this,"最近 30 天",12,UiKit.mutedColor(this),false));best.addView(bh);best.addView(UiKit.text(this,"更容易进入专注状态的时段",12,UiKit.mutedColor(this),false));HourBarView hv=new HourBarView(this);hv.setValues(DataStore.hourlyDistribution(all,30));best.addView(hv,new LinearLayout.LayoutParams(-1,UiKit.dp(this,240)));page.addView(best);

  page.addView(UiKit.space(this,14));LinearLayout heat=UiKit.card(this);LinearLayout hh=UiKit.row(this);hh.addView(UiKit.title(this,"年度热力图",19),new LinearLayout.LayoutParams(0,-2,1));hh.addView(UiKit.text(this,"近 12 周",12,UiKit.mutedColor(this),false));heat.addView(hh);heat.addView(UiKit.text(this,"颜色越深，专注时间越长",12,UiKit.mutedColor(this),false));HeatmapView hm=new HeatmapView(this);hm.setValues(DataStore.last84Days(all));heat.addView(hm,new LinearLayout.LayoutParams(-1,UiKit.dp(this,240)));LinearLayout legend=UiKit.row(this);String[] ls={"0m","1–30m","30m–2h","2h–5h",">5h"};for(String s:ls){TextView tx=UiKit.text(this,s,11,UiKit.mutedColor(this),false);tx.setGravity(Gravity.CENTER);legend.addView(tx,new LinearLayout.LayoutParams(0,UiKit.dp(this,30),1));}heat.addView(legend);page.addView(heat);
  root.addView(UiKit.bottomNav(this,3),new LinearLayout.LayoutParams(-1,UiKit.dp(this,64)));setContentView(root);
 }
 private void metric(LinearLayout row,String l,String v,String s){LinearLayout card=UiKit.metricCard(this,l,v,s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(0,0,UiKit.dp(this,8),0);row.addView(card,lp);}
}
