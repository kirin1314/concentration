package com.openai.randomfocus;

import android.content.*;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import java.util.Locale;

public class TimerRingView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); private long remain=40*60*1000L,total=40*60*1000L; private String subject="数学"; private boolean paused=false;
    public TimerRingView(Context c){super(c);} public TimerRingView(Context c,AttributeSet a){super(c,a);} public void setState(long r,long t,String s,boolean pause){remain=Math.max(0,r);total=Math.max(1,t);subject=s==null?"数学":s;paused=pause;invalidate();}
    private String fmt(long ms){long sec=ms/1000;if(sec>=3600)return String.format(Locale.getDefault(),"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60);return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);} 
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float r=Math.min(w,h)*.38f; p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(r*.09f);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(226,234,244));c.drawCircle(cx,cy,r,p);p.setColor(UiKit.BLUE);float prog=1f-remain/(float)total;RectF oval=new RectF(cx-r,cy-r,cx+r,cy+r);c.drawArc(oval,-90,360*prog,false,p);
        p.setStyle(Paint.Style.FILL);p.setColor(UiKit.textColor(getContext()));p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));p.setTextSize(r*.34f);c.drawText(fmt(remain),cx,cy+r*.08f,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(r*.10f);p.setColor(UiKit.mutedColor(getContext()));c.drawText(paused?"已暂停":"专注进行中",cx,cy+r*.30f,p);p.setTextSize(r*.105f);p.setColor(UiKit.BLUE_DARK);c.drawText("▣  "+subject,cx,cy+r*.48f,p);
    }
}
